"""
Match postal addresses (in a restricted form)
"""

from pathlib import Path
from itertools import chain
import regex

from typing import List, Iterable, Tuple

from postal.parser import parse_address


# Default address regexes for each language
ADDRESS_REGEX = {
    'es': r'<STREET> (?:\s\w+){1,5} ,? \s \d{1,4}',
    'de': r'\w+ \s? <STREET> \s \d{1,4}',
    'en': r'\d{1,4} (?:\s\w+){1,5} \s <STREET>'
}


def load_names(lang: str) -> Iterable[str]:
    """
    Load the list of street types for a language
    """
    fname = Path(__file__).parent / 'resources' / 'street' / f'{lang}.txt'
    with open(fname, encoding='utf-8') as f:
        data = [line.strip().split('|') for line in f]
    return chain.from_iterable(data)



class AddressExtractor:

    def __init__(self, lang: str, pattern: List[str] = None):

        street_pattern = '|'.join(map(regex.escape, load_names(lang)))
        street_pattern = '(?:' + street_pattern + ')'

        if not pattern:
            pattern = ADDRESS_REGEX[lang]
        if not isinstance(pattern, list):
            pattern = [pattern]

        pattern = [v.replace('<STREET>', street_pattern) for v in pattern]
        pattern = '|'.join(pattern)
        self.regex = regex.compile(pattern, flags=regex.I | regex.X)

    def __call__(self, text: str) -> Iterable[Tuple]:
        for m in self.regex.finditer(text):
            addr = m.group(0)
            parsed = parse_address(addr)
            if len(parsed) > 1:
                yield addr, m.start(), m.end()

