These are files contianing names of street-type elements, in different
languages.

They have been taken from libpostal, from the files

     resources/dictionaries/<LANG>/street_types.txt
